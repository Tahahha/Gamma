/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;
class HelloWorld {
    
    
  static long factorial(int n)
  {
    
    int result = 1;
    for (int i = 1; i <= n; i++)
    {
        
        result = result*i;
        
    }
    return result;
    
  }
  
  static long factorial2(int n)
  {
    int result = 1;
    int i = 1;
    while (i <= n)
    {
        
        result = result*n;
        n--;
        
    }
    return result;
    
  }
    
    
    static void Main() {
      Console.WriteLine("5! = " + factorial(5));
      Console.WriteLine("5! = " + factorial2(5));  
        
    }
    
    
  
}